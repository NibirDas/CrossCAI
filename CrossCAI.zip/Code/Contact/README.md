To run the code:
1. Download the zip file of the whole repo
2. Unzip the file 
3. Open any IDE or any terminal in the folder
4. Run the command *python main.py*